
"""
Government Job Notification Agent
--------------------------------
- Daily checks multiple govt job websites and sends a consolidated email to your Gmail.
- You MUST fill your Gmail address and App Password into config.json BEFORE running.
- Run: python3 main.py
"""

import requests
from bs4 import BeautifulSoup
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule
import time
import json
import hashlib
from datetime import datetime
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent
SEEN_FILE = BASE_DIR / "seen_jobs.json"
CONFIG_FILE = BASE_DIR / "config.json"

# ------------------ Utility ------------------
def load_config():
    if not CONFIG_FILE.exists():
        print("Missing config.json — please open config.json and fill YOUR_EMAIL, APP_PASSWORD, TO_EMAIL, CHECK_TIME.")
        sys.exit(1)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))

def load_seen():
    if not SEEN_FILE.exists():
        return {}
    return json.loads(SEEN_FILE.read_text(encoding="utf-8"))

def save_seen(seen):
    SEEN_FILE.write_text(json.dumps(seen, indent=2), encoding="utf-8")

def hash_item(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

# ------------------ Scrapers (simple / robust for many sites) ------------------
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; GovtJobAgent/1.0; +https://example.com)"}

def fetch_generic_jobs(url, max_items=15):
    """Fetch anchors and return list of (title, link)."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=20)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")
        items = []
        for a in soup.find_all("a"):
            title = a.get_text(strip=True)
            href = a.get("href") or ""
            if not title:
                continue
            # pick plausible job-related links by keywords or long text
            keywords = ["adv", "advert", "recruit", "result", "notification", "recruitment", "vacancy", "apply", "advertisement"]
            if any(k in title.lower() for k in keywords) or any(k in href.lower() for k in keywords):
                link = href if href.startswith("http") else requests.compat.urljoin(url, href)
                items.append((title, link))
            if len(items) >= max_items:
                break
        return items
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return []

# Specific site wrappers: you can expand these later
def fetch_ojas():
    return fetch_generic_jobs("https://ojas.gujarat.gov.in/advertisementList", max_items=20)

def fetch_ssc():
    return fetch_generic_jobs("https://ssc.nic.in/", max_items=20)

def fetch_upsc():
    return fetch_generic_jobs("https://www.upsc.gov.in/", max_items=20)

def fetch_railways():
    # Railway recruitment pages vary; use Indian Railways careers page as a start
    return fetch_generic_jobs("https://indianrailways.gov.in/", max_items=20)

def fetch_bank_jobs():
    # Use employment news / major bank career pages; generic scrape fallback
    return fetch_generic_jobs("https://www.bankofbaroda.in/careers", max_items=20)

def fetch_defence():
    return fetch_generic_jobs("https://joinindianarmy.nic.in/", max_items=20)

def fetch_employment_news():
    return fetch_generic_jobs("https://employmentnews.gov.in/", max_items=20)

def fetch_state_jobs():
    # Gujarat jobs (example) - fallback to state's employment portal
    return fetch_generic_jobs("https://ojas.gujarat.gov.in/advertisementList", max_items=20)

SOURCES = [
    ("OJAS (Gujarat)", fetch_ojas),
    ("SSC", fetch_ssc),
    ("UPSC", fetch_upsc),
    ("Railways", fetch_railways),
    ("Bank Jobs", fetch_bank_jobs),
    ("Defence / Army / Police", fetch_defence),
    ("Employment News", fetch_employment_news),
    ("State Govt Jobs", fetch_state_jobs),
]

# ------------------ Email ------------------
def send_email(cfg, subject, body):
    msg = MIMEMultipart()
    msg["From"] = cfg["YOUR_EMAIL"]
    msg["To"] = cfg["TO_EMAIL"]
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587, timeout=30)
        server.starttls()
        server.login(cfg["YOUR_EMAIL"], cfg["APP_PASSWORD"])
        server.sendmail(cfg["YOUR_EMAIL"], cfg["TO_EMAIL"], msg.as_string())
        server.quit()
        print(f"[{datetime.now().isoformat()}] Email sent to {cfg['TO_EMAIL']}")
        return True
    except Exception as e:
        print("Error sending email:", e)
        return False

# ------------------ Main job task ------------------
def job_task():
    cfg = load_config()
    seen = load_seen()
    new_items = []
    report_sections = []

    for name, func in SOURCES:
        print(f"Checking {name} ...")
        items = func()
        section_lines = []
        count_added = 0
        for title, link in items:
            h = hash_item(title + "|" + link)
            if h in seen:
                continue
            seen[h] = {"title": title, "link": link, "time": datetime.now().isoformat(), "source": name}
            new_items.append((name, title, link))
            section_lines.append(f"- {title}\n  {link}")
            count_added += 1
        if section_lines:
            report_sections.append(f"== {name} ({count_added} new) ==\n" + "\n".join(section_lines))

    # Always prepare a daily summary (even if no new items)
    if new_items:
        subject = f"Govt Job Updates — {len(new_items)} new — {datetime.now().strftime('%d %b %Y')}"
        body = "New Job Notifications found:\n\n" + "\n\n".join(report_sections)
    else:
        subject = f"Govt Job Updates — No new items — {datetime.now().strftime('%d %b %Y')}"
        body = "No new job notifications found at this check.\n\nChecked sources:\n" + "\n".join([s for s,_ in SOURCES])

    # send email
    sent = send_email(cfg, subject, body)
    if sent:
        save_seen(seen)

# ------------------ Entrypoint ------------------
def main():
    cfg = load_config()
    check_time = cfg.get("CHECK_TIME", "06:00")
    print(f"Agent scheduled to run daily at {check_time} (local time). Starting scheduler...")
    schedule.every().day.at(check_time).do(job_task)

    # Immediate run once at start (optional)
    print("Performing initial run now...")
    job_task()

    try:
        while True:
            schedule.run_pending()
            time.sleep(20)
    except KeyboardInterrupt:
        print("Agent stopped by user.")

if __name__ == "__main__":
    main()
