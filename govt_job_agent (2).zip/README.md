
# Government Job Notification Agent

**क्या है:** यह एक सरल Python Agent है जो दिए गए सरकारी वेबसाइट्स को चेक करता है और रोज़ाना आपकी Gmail पर नोटिफिकेशन भेजता है।  

**आपने बताया:** आप रोज़ सुबह `06:00` पर नोटिफिकेशन चाहते हैं — इसलिए default `CHECK_TIME` में `06:00` रखा गया है।

---

## फ़ाइलें
- `main.py` — मुख्य script (scheduler + scrapers + मेल भेजना)
- `config.json` — आपकी ईमेल और टाइम यहाँ भरें (जरूरी)
- `requirements.txt` — Python dependencies
- `run_agent.sh` — Linux / macOS के लिए रन स्क्रिप्ट
- `run_agent.bat` — Windows के लिए रन स्क्रिप्ट
- `seen_jobs.json` — पहले भेजे हुए नोटिफिकेशन्स का रिकॉर्ड (auto-generated)
- `README.md` — ये फाइल

---

## जरुरी - Gmail App Password कैसे बनाएं (बहुत जरूरी)
1. अपने Google Account पर जाएँ: `https://myaccount.google.com/security`
2. "2-Step Verification" ON करें (अगर पहले से नहीं है)
3. "App passwords" पर जाएँ
4. App = **Mail**, Device = **Other** (या अपना PC नाम दे दें) → Generate
5. जो 16-अंकीय password मिलेगा — उसे **config.json** में `"APP_PASSWORD"` के value के रूप में डालें (कोट्स के अंदर)

**IMPORTANT:** ये password कभी किसी के साथ शेयर न करें। इसे कभी भी चैट पर न भेजें।

---

## कैसे रन करें (Windows)
1. Python 3.8+ install करें।
2. Terminal (Command Prompt) खोलें और इस प्रोजेक्ट फ़ोल्डर में जाएँ।
3. dependencies install करें:
   ```
   pip install -r requirements.txt
   ```
4. `config.json` खोलकर `APP_PASSWORD` भरें।
5. चलाएँ:
   ```
   run_agent.bat
   ```

## कैसे रन करें (Linux / macOS)
1. Python 3.8+ install करें।
2. Terminal खोलें, प्रोजेक्ट फ़ोल्डर में जाएँ।
3. dependencies install करें:
   ```
   pip3 install -r requirements.txt
   ```
4. `config.json` में `APP_PASSWORD` भरें।
5. चलाएँ:
   ```
   bash run_agent.sh
   ```

---

## नोट्स और सुरक्षा
- मैं **कभी भी** आपका पासवर्ड नहीं मांगूंगा — खुद ही `config.json` में डालें।
- अगर आप चाहते हैं कि agent background में चले — आप इसे systemd service या Windows Task Scheduler में डाल सकते हैं; मैं वो सेटअप भी दे दूँगा अगर चाहो।
- Scraping rules बदल सकती हैं; अगर कोई साइट ब्लॉक कर दे तो आप मुझे बताइए, मैं site-specific scraping update कर दूँगा।

---

## मदद चाहिए?
अगर आप चाहें तो मैं step-by-step screen-by-screen बताऊँगा कि कैसे `APP_PASSWORD` बनाना है और `config.json` में डालकर Agent चलाना है — Hindi में। बस बोलो: **"Step-by-step batao"**
